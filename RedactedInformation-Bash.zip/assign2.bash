#!/bin/bash

DL_PATTERN="[A-Z]{2}DL [0-9]+"
MC_PATTERN='5[0-9]{3}-[0-9]{4}-[0-9]{4}-[0-9]{4}'
AMEX_PATTERN='3(4|7)[0-9]{2}-[0-9]{6}-[0-9]{5}'
VISA_PATTERN='4[0-9]{15}'
DISC_PATTERN='6[0-9]{3}-[0-9]{4}-[0-9]{4}-[0-9]{4}'
TXDLONE_PATTERN="TX ?[0-9A-Z]{3}-?[0-9A-Z]{3}"
TXDLTWO_PATTERN="TX ?[A-Z]{3}-?[0-9]{4}"

sed -i.sav -e "s/<date>/$(date +'%m\/%d\/%Y')/g" redactme.txt

sed -i.sav -f redact.sed "redactme.txt" 
